"# NavBallDockingAlignmentIndicator" 

Ever had the issue that when you were planning a rendevouz in space and wanted to dock to your target however it was a pain in the a** due to rotation of camera, lightning or some other reason? Well then this mod might be just the mod you are looking for. This will add a new Marker to the Navball to show if you are aligned with the targeted Dockingport. (You can also tell the targets rotation by it if you need it) and this will save you lot of fiddeling and switching back and forth to double and triple check. It really is just a minimalistic mod and yet so usefull

 

Features

Add a new marker to the navball to indicate Dockingport alignment
You can change the color of the marker via a config (r, g, b values)
 

